#ifndef HEADER2_H
#define HEADER2_H

struct IntRecordStruct {
   int fielda;
   int fieldb;
};

typedef struct IntRecordStruct INT_RECORD;

#endif
