#include "add.h"
#include "subtract.h"
#include "multiply.h"
#include "divide.h"

double Calculator (double input1, char Operator, double input2)
{
    double result = 0;

    switch (Operator)
    {
        case '+':
            result = add(input1, input2);
            break;
        case '-':
            result = subtract(input1, input2);
            break;
        case '*':
            result = multiply(input1, input2);
            break;
        case '/':
            result = divide(input1, input2);
            break;
        default:
            break;
    }
    return result;
}