#ifndef CALCULATOR_H
#define CALCULATOR_H

double Calculator(double input1, char Operator, double input2);

#endif
