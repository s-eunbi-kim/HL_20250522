#include "add.h"

double add(double x, double y)
{
    return x + y;
}
