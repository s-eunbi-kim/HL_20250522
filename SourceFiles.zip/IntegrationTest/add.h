#ifndef ADD_H
#define ADD_H

double add(double x, double y);

#endif
