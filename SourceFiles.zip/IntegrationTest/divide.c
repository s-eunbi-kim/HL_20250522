#include "divide.h"

double divide(double x, double y)
{
    if (y == 0.0)
        return 0.0; // or handle divide-by-zero appropriately
    return x / y;
}
