#ifndef DIVIDE_H
#define DIVIDE_H

double divide(double x, double y);

#endif
