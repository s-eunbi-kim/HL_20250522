#include "multiply.h"

double multiply(double x, double y)
{
    return x * y;
}
