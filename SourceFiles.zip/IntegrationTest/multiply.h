#ifndef MULTIPLY_H
#define MULTIPLY_H

double multiply(double x, double y);

#endif
