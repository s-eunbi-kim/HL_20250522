#include "subtract.h"

double subtract(double x, double y)
{
    return x - y;
}
