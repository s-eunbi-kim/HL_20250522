#ifndef SUBTRACT_H
#define SUBTRACT_H

double subtract(double x, double y);

#endif
