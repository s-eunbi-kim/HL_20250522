#ifndef vcast_time_H
#define vcast_time_H

typedef struct time {
    int mins ;
    int secs ;
} time_T ;


int invalid_time(time_T time_val);

#endif
