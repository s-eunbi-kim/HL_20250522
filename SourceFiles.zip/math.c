#include "math.h" 
#include "stdio.h"

#define Pi 3.14159
#define DIVIDE_BY_ZERO_ERROR -9999.9f

float g_result = 0;

float Add( float x, float y)
{
    g_result = x + y;
    return(g_result);
}

float Subtract( float x, float y)
{
    g_result = x - y;
    return(g_result);
}

float Multiply( float x, float y)
{
    g_result = x * y;
    return(g_result);
}

float Divide( float x, float y)
{
    g_result = x / y;
    return(g_result);
}

float Divide_stderr( float x, float y)
{
    if (y == 0.0f) {
        fprintf(stderr, "Error: Cannot divide by zero.\n");
        return DIVIDE_BY_ZERO_ERROR;  
    }

    g_result = x / y;
    return(g_result);
}