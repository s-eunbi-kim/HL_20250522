typedef struct {
   int data;
}   myType;