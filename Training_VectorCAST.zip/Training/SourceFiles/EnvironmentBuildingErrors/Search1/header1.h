#ifndef HEADER1_H
#define HEADER1_H

struct FloatRecordStruct {
   float field1;
   float field2;
};

typedef struct FloatRecordStruct FLOAT_RECORD;

#endif
