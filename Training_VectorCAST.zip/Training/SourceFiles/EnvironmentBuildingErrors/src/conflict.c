#include "stdio.h"
#include "conflict.h"

void conflict (myType P) {

   printf ("This is my value %d", P.data);
   
}