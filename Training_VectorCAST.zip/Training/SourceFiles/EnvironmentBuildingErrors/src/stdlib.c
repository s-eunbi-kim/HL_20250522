#include "stdlib.h"

int* callStdlib () {
    int* local = (int*)malloc (sizeof (int));
	return local;
	}