
extern int log_tax_receipts( float this_tax_ttl );
extern struct table_data_type Get_Table_Record(table_index_type Table);
extern void Update_Table_Record(table_index_type Table, float check_total, struct table_data_type Data);

